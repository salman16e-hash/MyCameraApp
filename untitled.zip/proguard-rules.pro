// Proguard rules
-keep class com.foldercam.manager.model.** { *; }
